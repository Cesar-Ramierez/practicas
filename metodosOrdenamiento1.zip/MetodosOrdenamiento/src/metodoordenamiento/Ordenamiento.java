package metodoordenamiento;

public class Ordenamiento extends ArregloUni
{
    public void burbuja_der_izq()
    {int i,j;
        for(i=1;i<=n-1;i++)
        {System.out.println("Recorrido"+i);//sirve para q en cada recorrido lo valla imprimiendo
            for(j=n-1;j>=i;j--)
                {if(a[j-1]>a[j])
                cambio(a,j-1,j);
                reporte();// se pone para q cada recorrido valla reportando
                }
            }
    }
    public void burbuja_izq_der()
    {int i,j;
        for(i=n-2;i>=0;i--)
        {System.out.println("Recorrido"+-((i-n)+1));
            for(j=0;j<=i;j++)
                {
                    if(a[j]>a[j+1])
                cambio(a,j,j+1);
                reporte();
                }
            }
 
            }
 
    public void cambio(int[]a,int pos1,int pos2)
    {
        int t;
        t=a[pos1];
        a[pos1]=a[pos2];
        a[pos2]=t;
    }
 
    public void baraja()
    {
        int i,j,aux;
        for(i=1;i<=n-1;i++)
        {
            aux=a[i];
            j=i-1;
            while(a[j]>aux && j>0)
            {
                a[j+1]=a[j];
                j--;
            }
 
            if(a[j]>aux)
            {
                a[j+1]=a[j];
                a[j]=aux;
            }
            else
                a[j+1]=aux;
        }
    }
 
    public void seleccion_directa()
    {
        int i,j,k,aux;
        for(i=0;i<=n-2;i++)
        {
            k=1;
            aux=a[i];
            for(j=i+1;j<=n-1;j++)
                if(a[j]<aux)
                {
                    k=j;
                    k=a[j];
                }
 
                a[k]=a[i];
                a[i]=aux;
        }
    }
 
    public void shell()
    {
        int d,i,sw;
        d=n;
        do{
            d=d/2;
            do{
                sw=0;
                i=-1;
                do{
                    i++;
                    if(a[i]>a[i+d])
                    {
                        cambio(a,i,i+d);
                        sw=1;
                    }
                }while(i+d!=n-1);
            }while(sw!=0);
        }while(d!=1);
    }
 
    public static void quicksort(int A[], int izq, int der) {

  int pivote=A[izq]; // tomamos primer elemento como pivote
  int i=izq;         // i realiza la búsqueda de izquierda a derecha
  int j=der;         // j realiza la búsqueda de derecha a izquierda
  int aux;
 
  while(i < j){                          // mientras no se crucen las búsquedas                                   
     while(A[i] <= pivote && i < j) i++; // busca elemento mayor que pivote
     while(A[j] > pivote) j--;           // busca elemento menor que pivote
     if (i < j) {                        // si no se han cruzado                      
         aux= A[i];                      // los intercambia
         A[i]=A[j];
         A[j]=aux;
     }
   }
   
   A[izq]=A[j];      // se coloca el pivote en su lugar de forma que tendremos                                    
   A[j]=pivote;      // los menores a su izquierda y los mayores a su derecha
   
   if(izq < j-1)
      quicksort(A,izq,j-1);          // ordenamos subarray izquierdo
   if(j+1 < der)
      quicksort(A,j+1,der);          // ordenamos subarray derecho
}
}