package busqueda.secuncial;

import java.util.Scanner;

public class BusquedaSecuncial {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int numero, i = 0, pos = 0, vec[] = {3, 65, 8, 1, 2, 88, 9, 0, 6, 2};
        boolean encontro = false;
        System.out.println("Ingresa el numero a buscar:  ");
        numero = sc.nextInt();
        while (!(encontro) && i < 10) {
            if (numero == vec[i]) {
                encontro = true;
                pos = i;
            }
            i = i + 1;
        }
        if (encontro) {
            System.out.println("el numero se encontro y esta en la posicion:  " + pos + 1);
        }
    }

}
