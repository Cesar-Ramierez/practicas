package torres.de.hanoi;

import java.util.Scanner;

public class TorresDeHanoi {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Ingresa el numero de discos: ");
        n = sc.nextInt();
        Hanoi(n,"Torre A","Torre B","Torre C");  //Torre A:origen     Torre B:auxiliar     Torre C:destino                                                         
    }

    public static void Hanoi(int n, String torreA, String torreB, String torreC){
        if(n==1){
           System.out.println("mover disco " + n +" de " + torreA + " a " +  torreC);
        }else{
           Hanoi(n-1, torreA,  torreC, torreB);
           System.out.println("mover disco "+ n +" de "+  torreA + " a " +  torreC);
           Hanoi(n-1, torreB, torreA,  torreC);
        }
    }
}
